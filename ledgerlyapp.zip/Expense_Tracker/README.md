# Ledgerly — Personal Finance & Shared Expense Tracker

A personal ledger first, a shared-expense platform second, on the same data.
Implementation of the **Ledgerly PRD v1.0** and **Architecture & Database Design** docs
(see `project/` for the original design handoff; `HANDOFF.md` explains the bundle).

**Standing product rule: no AI/LLM anywhere.** Natural-language search,
auto-categorization, settlement suggestions and import detection are all
deterministic and rule-based.

## Stack

- **Next.js 15** (App Router) · React 19 · TypeScript · Tailwind CSS 4
- **PostgreSQL** (Supabase in production) · **Prisma 6**
- **Better Auth** (email + password, sessions in your own DB)
- All money is **integer paise** (`BigInt` columns); `Intl.NumberFormat('en-IN')`
  formatting at the edge only (₹1,23,456). Timezone: Asia/Kolkata.

## Quick start

```bash
npm install
cp .env.example .env        # set DATABASE_URL + BETTER_AUTH_SECRET (openssl rand -hex 32)
npx prisma migrate dev      # creates schema + split-sum DB trigger
npm run db:seed             # demo user with 6 months of realistic data
npm run dev                 # http://localhost:3000
```

Demo login: **arjun@ledgerly.app / ledgerly-demo** — or sign up fresh
(new users get the 28 default categories, the merchant→category dictionary,
and a starter Cash account).

```bash
npm test                    # unit tests: split rounding, settlement engine, parser, money
node scripts/e2e.mjs        # browser walkthrough (needs `npm start` running + Chromium)
```

## What's implemented (M1–M5 of the build order)

| Area | Status |
|---|---|
| **Accounts & transfers** | CRUD, 5 account types, internal transfers (incl. credit-card payment), running balances maintained in-transaction and rebuildable (`balance = openingBalance + Σ ledger` — verified in e2e) |
| **Transactions** | Expense / income / transfer in one table; quick-add via FAB, top bar and ⌘K; soft delete with undo toast; split/recurring/receipt badges |
| **Categories** | 28 seeded defaults + rule-based auto-categorization (merchant→category table, self-improving on manual re-categorization) |
| **Budgets** | Monthly per-category, 80%/amber + 100%/red thresholds, exactly-once notifications per budget per period (dedupe key), attention-strip surfacing |
| **Bills** | Due-date urgency chips, "mark paid" creates the payment transaction and rolls the due date by cadence |
| **Recurring** | `RecurringRule` engine materialized by `/api/cron/daily` (Vercel Cron, idempotent) |
| **Dashboard** | Attention strip, Total Balance dark card, cash flow (6M/8W/14D), accounts widget, category donut, upcoming bills, settlements, recent txns, budget bars |
| **Search** | Deterministic parser in ⌘K ("swiggy in march", "upi expenses", "food above ₹500 last month") answering inline with total + count; one click opens the filtered list; falls back to text search |
| **Shared** | Ghost participants (no signup needed), groups, equal/exact splits with **remainder paise to the payer** (DB trigger enforces Σ splits = total), net balances, greedy min-transaction settlement engine, settle up (UPI/cash/bank), history |
| **Analytics** | Avg daily spend, biggest expense, savings rate, balance trend, monthly spending, top categories & merchants |
| **UX** | Glass & Ink design (pixel-matched to the prototype), dark mode (cookie-persisted, no flash), responsive: sidebar ≥760px → bottom tab bar + bottom sheets + FAB below, toasts with undo |

**Not yet built** (schema + service seams are ready): Monito import wizard (M6 —
`ImportBatch`/`ImportMapping` models and adapter interface exist), receipt uploads
(Supabase Storage), CSV/XLSX/PDF exports, email invitations linking ghost
participants to real users, in-app notification center UI.

## Architecture

Three strict layers (UI never touches Prisma; services never touch HTTP):

```
src/
├─ app/                   # routes; (app)/ = authed shell, (auth)/ = sign-in/up
│  ├─ actions.ts          # server actions: zod-validate → service → revalidate
│  └─ api/                # Better Auth handler + cron route
├─ components/shell/      # app chrome: sidebar, modals, ⌘K palette, FAB, toasts
├─ server/
│  ├─ services/           # domain logic (transactions, budgets, bills, shared, …)
│  ├─ auth.ts             # Better Auth config (+ per-user seeding on signup)
│  └─ db.ts               # Prisma singleton
├─ lib/                   # pure logic: money (paise), dates (IST), settlement,
│  │                      #   search-parser, tx-display — all unit-testable
└─ validators/            # zod schemas, money parsed to paise at the boundary
prisma/schema.prisma      # full schema, all 3 phases — migrate once
```

Key invariants, enforced in code **and** the database:

- Every mutation runs in one DB transaction that updates account balances and
  appends an `AuditLog` row.
- `Σ ExpenseSplit.owedAmount = Transaction.amount` via a deferred Postgres
  constraint trigger (`prisma/migrations/*_split_sum_constraint`).
- Budget notifications are exactly-once per period via a unique dedupe key.
- The recurring cron is idempotent: `nextRunAt` advances atomically with the
  materialized row.

## Deployment (Vercel + Supabase)

1. Create a Supabase project; put the **pooled** connection string in `DATABASE_URL`.
2. `npx prisma migrate deploy`
3. Set `BETTER_AUTH_SECRET`, `BETTER_AUTH_URL` (your domain) and `CRON_SECRET`
   in Vercel env; `vercel.json` schedules the daily job at 00:30 IST.
